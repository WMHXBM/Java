package test1006;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import test1006.Login;


import java.sql.*;
public class Insert extends JFrame implements ActionListener{
	JLabel lab1,lab2,lab3,lab4;
	JTextField txtid,txtname;
	JPasswordField txtpwd;
	JRadioButton rdman,rdwoman;
	JButton btnOk,btnCancel,btnlogin;
	ButtonGroup sex=new ButtonGroup();
	public Insert(){
		super("�û�ע��");
		Container c=this.getContentPane();
		c.setLayout(null);
		lab1=new JLabel("�˺ţ�",JLabel.CENTER);
		lab2=new JLabel("������",JLabel.CENTER);
		lab3=new JLabel("���룺",JLabel.CENTER);
		lab4=new JLabel("�Ա�",JLabel.CENTER);
		txtid=new JTextField("");
		txtname=new JTextField("");
		txtpwd=new JPasswordField("");
		rdman=new JRadioButton("��",true);
		rdwoman=new JRadioButton("Ů");
		btnOk=new JButton("ע��");
		btnCancel=new JButton("ȡ��");
		btnlogin=new JButton("ǰ����¼");
		sex.add(rdman);
		sex.add(rdwoman);
		lab1.setBounds(30,30,60,20);
		txtid.setBounds(100,30,150,20);
		lab2.setBounds(30,70,60,20);
		txtname.setBounds(100,70,150,20);
		lab3.setBounds(30,110,60,20);
		txtpwd.setBounds(100,110,150,20);
		lab4.setBounds(30,150,60,20);
		rdman.setBounds(100,150,70,20);
		rdwoman.setBounds(170,150,70,20);
		btnOk.setBounds(60,190,80,30);		
		btnCancel.setBounds(150,190,80,30);
		btnlogin.setBounds(60,240,170,30);
		c.add(lab1);
		c.add(lab2);
		c.add(lab3);
		c.add(lab4);
		c.add(txtid);
		c.add(txtname);
		c.add(txtpwd);
		c.add(rdman);
		c.add(rdwoman);
		c.add(btnOk);
		c.add(btnCancel);
		c.add(btnlogin);
		btnOk.addActionListener(this);
		btnCancel.addActionListener(this);
		btnlogin.addActionListener(this);
		
		
		this.setSize(300,350);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
	}
	public static void main(String[] args) {
		new Insert();

	}
	void ClearTxt(){
		txtid.setText("");
		txtname.setText("");
		txtpwd.setText("");
		rdman.setSelected(true);
	}
	
	
	int SelectID(int id){//�˷����Ĺ���Ϊ��֤�˺��Ƿ��Ѿ�����
		int m=0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			JOptionPane.showMessageDialog(null,"��������ʧ�ܣ�");
		}
		try {
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/stumis","root","root");
			String sql="select count(*) from user where userid="+id;
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				m=rs.getInt(1);
			}
			rs.close();
			st.close();
			con.close();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null,"SQL�쳣��");
		}
		return m;
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==btnOk){
			int count=SelectID(Integer.parseInt(txtid.getText()));
			if(count==0){
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e1) {
				JOptionPane.showMessageDialog(null,"��������ʧ�ܣ�");
			}
			try {
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/stumis","root","root");
				int id=Integer.parseInt(txtid.getText());
				String name=txtname.getText();
				String pwd=txtpwd.getText();
				String sex="";
				
				
				if(rdman.isSelected()){
					sex=rdman.getText();
				}
				else if(rdwoman.isSelected()){
					sex=rdwoman.getText();
				}
				
				
                String sql="insert into user values("+id+",'"+name+"','"+pwd+"','"+sex+"')";
                Statement st=con.createStatement();
                int i=st.executeUpdate(sql);
                if(i==1){
                	JOptionPane.showMessageDialog(null,"ע��ɹ���");
                	ClearTxt();
                }
                st.close();
                con.close();
			} catch (SQLException e1) {
				JOptionPane.showMessageDialog(null,"ע��ʧ�ܣ�");
				ClearTxt();
			}
			}
			else if(count==1){
				JOptionPane.showMessageDialog(null,"���˺��Ѿ���ע���");
				txtid.requestFocus();
				txtid.selectAll();
			}
		}
		else if(e.getSource()==btnCancel){
			ClearTxt();
		}
		else if(e.getSource()==btnlogin){
			Login login=new Login();
			this.hide();
		}
		
	}

}
