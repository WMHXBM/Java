package test1006;
import java.sql.*;

import javax.swing.table.DefaultTableModel;
public class Opertator {
 private static Connection con;
 
 public static DefaultTableModel selectPublishers(){//��ѯ���г�������Ϣ,����ģ����
  DefaultTableModel model=new DefaultTableModel(){
  public boolean isCellEditable(int row,int col){
   return false;
  }
  };
  model.addColumn("��������");
  model.addColumn("����������");
  model.addColumn("�������ַ");
  model.addColumn("������绰");
  model.addColumn("�����縺����");
  con=ConnectionDB.openDB();
  String sql="select*from publishers";
  try{
   Statement st=con.createStatement();
   ResultSet rs=st.executeQuery(sql);
   while(rs.next()){
    String a[]={String.valueOf(rs.getInt(1)),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)};
    model.addRow(a);
   }
   rs.close();
   st.close();
   con.close();
  }catch (SQLException e){
   e.printStackTrace();
  } 
  return model;
 }
 
 
 public static int SelectPublisherID(int id){
	 int n=0;
	 con=ConnectionDB.openDB();
	 String sql="select count(*) from publishers where publisherid="+id+"";
	 try {
		Statement st=con.createStatement();
		 ResultSet rs=st.executeQuery(sql);
		 while(rs.next()){
			    n=rs.getInt(1);
			   }
		 rs.close();
		   st.close();
		   con.close();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	 return n;
 }
 //���淽��
 public static void Save(int id,String name,String address,String tel,String chairman){
	 con=ConnectionDB.openDB();
	 String sql="insert into publishers values(?,?,?,?,?)";
	 try {
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setInt(1, id);
		pst.setString(2, name);
		pst.setString(3, address);
		pst.setString(4, tel);
		pst.setString(5, chairman);
		pst.executeUpdate();
		pst.close();
		con.close();
	} catch (SQLException e) {
		e.printStackTrace();
	}
 }
 //�޸ķ���
 public static void Update(int id,String name,String address,String tel,String chairman){
	 con=ConnectionDB.openDB();
	 String sql="update publishers set publishername=?,address=?,tel=?,chairman=? where publisherid=?";
	 try {
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setString(1, name);
		pst.setString(2, address);
		pst.setString(3, tel);
		pst.setString(4, chairman);
		pst.setInt(5, id);
		pst.executeUpdate();
		pst.close();
		con.close();
	} catch (SQLException e) {	
		e.printStackTrace();
	}
 }
 //ɾ������
 public static void Delete(int id){
	 con=ConnectionDB.openDB();
	 String sql="delete from publishers where publisherid="+id+"";
	 try {
		Statement st=con.createStatement();
		st.executeUpdate(sql);
		st.close();
		con.close();
	} catch (SQLException e) {
		e.printStackTrace();
	}
 }
 
 
 
}


