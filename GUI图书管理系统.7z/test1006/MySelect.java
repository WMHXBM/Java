package test1006;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.sql.*;
public class MySelect extends JFrame implements ActionListener,MouseListener{
	JLabel lab1=new JLabel("�������ţ�",JLabel.CENTER);
	JLabel lab2=new JLabel("���������ƣ�",JLabel.CENTER);
	JLabel lab3=new JLabel("�������ַ��",JLabel.CENTER);
	JLabel lab4=new JLabel("������绰��",JLabel.CENTER);
	JLabel lab5=new JLabel("�����縺���ˣ�",JLabel.CENTER);
	JTextField txtid=new JTextField("");
	JTextField txtname=new JTextField("");
	JTextField txtaddress=new JTextField("");
	JTextField txttel=new JTextField("");
	JTextField txtchairman=new JTextField("");
	JButton btnSave=new JButton("����");
	JButton btnCancel=new JButton("ȡ��");
	JButton btnUpdate=new JButton("�޸�");
	JButton btnDelete=new JButton("ɾ��");
	JTable table;
	public MySelect(){
		super("��������Ϣ����");
		this.setSize(800,370);
		this.setLocationRelativeTo(null);
		JPanel p=new JPanel(null);
		JPanel p1=new JPanel(new GridLayout(7,2,10,10));
		JPanel p2=new JPanel(new GridLayout(1,1,10,10));
		p.setBorder(new EmptyBorder(20,20,20,20));
		p1.setBounds(10,15,200,300);
		p2.setBounds(220,15,550,300);
		p1.add(lab1);p1.add(txtid);
		p1.add(lab2);p1.add(txtname);
		p1.add(lab3);p1.add(txtaddress);
		p1.add(lab4);p1.add(txttel);
		p1.add(lab5);p1.add(txtchairman);
		p1.add(btnSave);p1.add(btnCancel);
		p1.add(btnUpdate);p1.add(btnDelete);
		table=new JTable(Opertator.selectPublishers());//��table����ʾ������Ϣ
		p2.add(new JScrollPane(table));
		p.add(p1);
		p.add(p2);
		this.setContentPane(p);
		this.setVisible(true);
		btnSave.addActionListener(this);
		btnCancel.addActionListener(this);
		btnUpdate.addActionListener(this);
		btnDelete.addActionListener(this);
		table.addMouseListener(this);
		btnUpdate.setEnabled(false);
		btnDelete.setEnabled(false);
	}
	
	public static void main(String[] args) {
		new MySelect();
	}
	public void Clear(){
		txtid.setText("");
		txtname.setText("");
		txtaddress.setText("");
		txttel.setText("");
		txtchairman.setText("");
		btnSave.setEnabled(true);
		btnCancel.setEnabled(true);
		btnUpdate.setEnabled(false);
		btnDelete.setEnabled(false);
		txtid.setEnabled(true);
		txtid.requestFocus();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==btnSave){
		if(txtid.getText().equals("")){
				JOptionPane.showMessageDialog(null,"�������Ų�����Ϊ��ֵ��");
				txtid.requestFocus();
				return;
			}
		else if(txtname.getText().equals("")){
			JOptionPane.showMessageDialog(null,"���������Ʋ�����Ϊ��ֵ��");
			txtname.requestFocus();
			return;
		}
		else{
			int id=Integer.parseInt(txtid.getText());
			int count=Opertator.SelectPublisherID(id);//���ò鿴id�Ƿ�ʹ�õķ���
			if(count==0){
				String name=txtname.getText();
				String address=txtaddress.getText();
				String tel=txttel.getText();
				String chairman=txtchairman.getText();
				Opertator.Save(id, name, address, tel, chairman);
				table.setModel(Opertator.selectPublishers());
				Clear();
			}
			else{
				JOptionPane.showMessageDialog(null,"�������Ų��Ѿ����ڣ��������ţ�");
				txtid.requestFocus();
				txtid.selectAll();
				
			}
		}
	
	}
		else if(e.getSource()==btnCancel){
			Clear();
		}
		else if(e.getSource()==btnUpdate){
			if(txtname.getText().equals("")){
				JOptionPane.showMessageDialog(null,"���������Ʋ���Ϊ��ֵ");
				txtname.requestFocus();
				return;
			}
			Opertator.Update(Integer.parseInt(txtid.getText()), txtname.getText(), txtaddress.getText(), txttel.getText(), txtchairman.getText());
			table.setModel(Opertator.selectPublishers());//ˢ�±���
			Clear();
		}
        else if(e.getSource()==btnDelete){
        	if(JOptionPane.showConfirmDialog(null,"��ȷ��ɾ����","ɾ����ʾ",JOptionPane.YES_NO_OPTION)==0){
			    Opertator.Delete(Integer.parseInt(txtid.getText()));
			    table.setModel(Opertator.selectPublishers());
        	}
			Clear();
		}
}

	public void mouseClicked(MouseEvent e) {
		if(e.getClickCount()==1){
			txtid.setText(table.getValueAt(table.getSelectedRow(),0).toString());
			txtname.setText(table.getValueAt(table.getSelectedRow(),1).toString());
			if(table.getValueAt(table.getSelectedRow(), 2)==null)
				txtaddress.setText("");
			else
			    txtaddress.setText(table.getValueAt(table.getSelectedRow(),2).toString());
			
			txttel.setText(table.getValueAt(table.getSelectedRow(),3).toString());
			txtchairman.setText(table.getValueAt(table.getSelectedRow(),4).toString());
		    btnSave.setEnabled(false);
		    btnCancel.setEnabled(true);
		    btnUpdate.setEnabled(true);
		    btnDelete.setEnabled(true);
		    txtid.setEnabled(false);
		}
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}