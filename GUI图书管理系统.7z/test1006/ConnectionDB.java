package test1006;

import java.sql.*;

public class ConnectionDB {
	private static String driver="com.mysql.jdbc.Driver";
	private static String url="jdbc:mysql://localhost:3306/stumis?charerEncoding=utf8";
	private static String user="root";
	private static String pwd="root";
	private static Connection con=null;
	//�����ݿ����ӵķ���
	public static Connection openDB(){
		try {
			Class.forName(driver);
			con=DriverManager.getConnection(url,user,pwd);
		}
			 catch (SQLException e) {
				
				e.printStackTrace();
			}
		 catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		return con;
	}
	//�ر����ݿ����ӵķ���
	public static void closeDB(){
		try {
			con.close();
		} catch (SQLException e) {			
			e.printStackTrace();
		}
	}

}
