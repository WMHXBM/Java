package test1006;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.AncestorListener;

import test1006.Insert;


import java.sql.*;


public class Login  extends JFrame implements ActionListener{
	JLabel lab1,lab2;
	JTextField txtid;
	JPasswordField txtpwd;
	JButton btnOk,btnCancel,btnZhuce;
	public static Connection con=null;
	public Login(){
		super("��¼");
		Container c=this.getContentPane();
		c.setLayout(null);
		lab1=new JLabel("�˺ţ�");
		lab2=new JLabel("���룺");
		txtid=new JTextField();
		txtpwd=new JPasswordField();
		btnOk=new JButton("��¼");
		btnCancel=new JButton("ȡ��");
		btnZhuce=new JButton("ע��");
		lab1.setBounds(30,30,60,20);
		lab2.setBounds(30,70,60,20);
		txtid.setBounds(100,30,150,20);
		txtpwd.setBounds(100,70,150,20);
		btnOk.setBounds(30,110,60,30);
		btnCancel.setBounds(110,110,60,30);
		btnZhuce.setBounds(190,110,60,30);
		btnZhuce.addActionListener(this);
		btnOk.addActionListener(this);
		btnCancel.addActionListener(this);
		c.add(lab1);
		c.add(lab2);
		c.add(txtid);
		c.add(txtpwd);
		c.add(btnOk);
		c.add(btnCancel);
		c.add(btnZhuce);
		this.setSize(300,200);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	public static void main(String[] args) {
		new Login();

	}
	public static Connection openDB(){
			try {
				Class.forName("com.mysql.jdbc.Driver");
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/stumis?characterEncoding=utf8","root","root");
			} catch (ClassNotFoundException e) {
				
				e.printStackTrace();
			}
			 catch (SQLException e) {
				e.printStackTrace();
			}
		 return con;
		 }
	public static void closeDB(){

		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
		
	public void Clear(){
		txtid.setText("");
		txtpwd.setText("");
	}
	public int selectUser(int id,String pwd){
		int n=0;
		openDB();
		String sql="select count(*) from user where userid="+id+" and userpwd='"+pwd+"'"; 
		
		try {
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				n=rs.getInt(1);		
			}
			st.close();
			rs.close();
			closeDB();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return n;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==btnZhuce){
			new Insert();
		}
		else if(e.getSource()==btnOk){
			int a=Integer.parseInt(txtid.getText());
			String b=txtpwd.getText();
			int count=selectUser(a,b);
			if(count==1){
				JOptionPane.showMessageDialog(null,"��¼�ɹ�");
				Clear();
				new MySelect();
				this.hide();
			}
			else if(count==0){
				JOptionPane.showMessageDialog(null,"�˺Ż���������");
				Clear();
			}
		}
		else if(e.getSource()==btnCancel){
			Clear();
		}
		
	}

}
